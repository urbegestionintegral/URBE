<!--<footer class="full-row bg-secondary p-0">-->
<footer class="full-row p-0 mb-2 bg-secondary text-white">
            <div class="container">
                <div  class="row">
                    <div class="col-lg-12">
                        <div class="divider py-40">
                            <div class="row">
                                <div class="col-md-12 col-lg-4">
                                    <div class="footer-widget mb-4">
                                        <div align="center" class="footer-logo mb-4"> <a href="#"><img class="logo-bottom" src="images/logo/logo-white.png" width="800" height="200" alt="image"></a> 
                                        <!--<p class="pb-20 text-white">FLORO.</p>-->
										<p class="pb-20 text-white"><b>SIGUENOS EN NUESTRAS REDES</b>
										 <div class="footer-widget media-widget mt-4 text-white hover-text-secondary"> <a target="_blank" href="https://www.facebook.com/urbegestionintegralperu"><i class="fab fa-facebook-f"></i></a> <a target="_blank" href="https://www.instagram.com/gestionurbe/"><i class="fab fa-instagram"></i></a></div></div> 
											<!--<a href="#"><i class="fab fa-google-plus-g"></i></a> 
											<a href="#"><i class="fab fa-linkedin-in"></i></a> 
											<a href="#"><i class="fas fa-rss"></i></a> </div>-->
									   </div>
                                </div>
                                <div class="col-md-12 col-lg-8">
                                    <div class="row">
                                        <div class="col-md-4 col-lg-4">
                                            <div class="footer-widget footer-nav mb-4">
                                                <h4 class="widget-title text-white double-down-line-left position-relative">Soporte</h4>
                                                <ul class="hover-text-secondary">
                                                    <li><a href="#" class="text-white">Foro</a></li>
                                                    <li><a href="#" class="text-white">Estadísticas</a></li>
                                                    <li><a href="#" class="text-white">Términos y Condiciones</a></li>
                                                    <li><a href="#" class="text-white">Soporte</a></li>
                                                    <li><a href="#" class="text-white">Preguntas Frecuentes</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-lg-4">
                                            <div class="footer-widget footer-nav mb-4">
                                                <h4 class="widget-title text-white double-down-line-left position-relative">Enlaces Rápidos</h4>
                                                <ul class="hover-text-secondary">
                                                    <li><a href="#" class="text-white">Quienes Somos</a></li>
                                                    <li><a href="#" class="text-white">Propiedades Destacadas</a></li>
                                                    <li><a href="#" class="text-white">Conviértete en miembro</a></li>
                                                    <li><a href="#" class="text-white">Registrar Propiedad</a></li>
                                                    <li><a href="#" class="text-white">Como Funciona</a></li>
                                                    <li><a href="#" class="text-white">Nuestros Agentes</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-lg-4">
                                            <div class="footer-widget">
                                                <h4 class="widget-title text-white double-down-line-left position-relative">Contactanos</h4>
                                                <ul class="text-white">
                                                    <li class="hover-text-secondary"><i class="fas fa-map-marker-alt text-white mr-2 font-13 mt-1"></i>Calle Doña Amalia 147 - Santiago de Surco</li>
                                                    <li class="hover-text-secondary"> <i class="fas fa-phone-alt text-white mr-2 font-13 mt-1"></i>981 244 677</li>
													<li class="hover-text-secondary"> <i class="fas fa-phone-alt text-white mr-2 font-13 mt-1"></i>936 885 735</li>
                                                    <li class="hover-text-secondary"><i class="fas fa-envelope text-white mr-2 font-13 mt-1"></i>casalarcon3@gmail.com</li>
                                                    <li class="hover-text-secondary"><i class="fas fa-envelope text-white mr-2 font-13 mt-1"></i>urbeintegralsac@gmail.com</li>
                                                </ul>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row copyright">
                    <div class="col-sm-6"> <span class="text-white">URBE - Gestión Integral © 2024</span> </div>
                    <div class="col-sm-6">
                        <ul class="line-menu text-white hover-text-secondary float-right">
                            <li><a href="#">Política de privacidad</a></li>
                            <li>|</li>
                            <li><a href="#">Mapa del Sitio</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>