<?php
$dbhost = "sql105.infinityfree.com"; // Host del MySQL
$dbuser = "if0_36978132"; // Usuario del MySQL
$dbpass = "T3MPL3666"; // Password del MySQL
$db = "if0_36978132_urbe"; // Base de datos donde se crear� la tabla users

// Conectamos y seleccionamos la base de datos usando mysqli
$connection = new mysqli($dbhost, $dbuser, $dbpass, $db);

// Verificamos si la conexi�n fue exitosa
if ($connection->connect_error) {
    die("Error de conexi�n: " . $connection->connect_error);
}

// Comenzamos la sesi�n, esto se explica despu�s en el sistema de login
session_start();
?>